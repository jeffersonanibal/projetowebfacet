from django.contrib import admin
from django.urls import path
from django.urls import path, include
from django.views.generic import TemplateView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('Ouvidoria.urls', namespace='Ouvidoria')),
    path('', TemplateView.as_view(template_name='ExNav.html')),
    path('Sugestoes/', TemplateView.as_view(template_name='Sugestao.html')),
    path('Login/', TemplateView.as_view(template_name='Login.html')),
    path('Denuncias/', TemplateView.as_view(template_name='Denuncia.html')),
    path('Reclamacoes/', TemplateView.as_view(template_name='Reclamacoes.html')),
    path('Elogios/', TemplateView.as_view(template_name='Elogios.html')),
    path('Home/', TemplateView.as_view(template_name='registration/telaLogin.html')),
]
