from django.shortcuts import render
from .models import Sugestoes
from django.shortcuts import render, HttpResponse
from django.contrib.auth.decorators import login_required

def Ouvidoria(request):
    return render(request,"templates/ExNav.html")

def sugestao(request):
    titulos = Sugestoes.object.order_by('codigo')
    context = {'titulos':titulos}
    return render(request,"templates/Sugestao.html", context)

def denuncia(request):
    titulos = Denuncias.object.orber_by('codigo')
    context = {'titulos':titulos}
    return render(request,"templates/Denuncia.html", context)

def reclamacoes(request):
    titulos = Reclamacoes.object.orber_by('codigo')
    context = {'titulos':titulos}
    return render(request,"Ouvidoria/Reclamacoes.html", context)


def elogios(request):
    titulos = Elogios.object.orber_by('codigo')
    context = {'titulos':titulos}
    return render(request,"templates/Elogios.html", context)

def Login(request):
    return render(request,"templates/registration/Login.html")

@login_required
def Home(request):
    return render(request,"templates/registration/telaLogin.html")