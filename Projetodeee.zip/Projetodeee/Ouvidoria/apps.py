from django.apps import AppConfig


class OuvidoriaConfig(AppConfig):
    name = 'Ouvidoria'
